#include "graph.h"
#include <stdio.h>


extern Graph* kruskalMST(Graph *g);
void test3() {
	Graph g;
	/*
		create(&g, DIRECTED);
		insertNode(&g, 0);
		insertNode(&g, 1);
		insertNode(&g, 2);
		insertNode(&g, 3);
		insertNode(&g, 4);

		insertEdge(&g, 0, 1, 16);
		insertEdge(&g, 0, 2, 2);
		insertEdge(&g, 0, 3, 11);
		insertEdge(&g, 0, 4, 9);
		insertEdge(&g, 1, 3, 5);
		insertEdge(&g, 2, 3, 16);
		insertEdge(&g, 2, 4, 3);
		insertEdge(&g, 3, 4, 1);

		print(&g);
		graphvizDriver2(&g);

		Graph* mst = kruskalMST(&g);
		print(mst);
		graphvizDriver2(mst);
		*/
		//////////////////////////////////////////

	create(&g, UNDIRECTED);
	insertNode(&g, 0);
	insertNode(&g, 1);
	insertNode(&g, 2);
	insertNode(&g, 3);
	insertNode(&g, 4);
	insertNode(&g, 5);

	insertEdge(&g, 0, 1);
	insertEdge(&g, 0, 2);
	insertEdge(&g, 0, 3);
	insertEdge(&g, 0, 4);
	insertEdge(&g, 1, 2);
	insertEdge(&g, 2, 3);
	insertEdge(&g, 2, 4);
	insertEdge(&g, 2, 5);
	insertEdge(&g, 3, 4);

	print(&g);
	graphvizDriver(&g);

	Graph* st = spanningTreeDriver(&g);
	graphvizDriver(st);


}


int main() {
	test3();
	return 0;
}