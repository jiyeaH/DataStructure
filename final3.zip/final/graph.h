#pragma once

#include <stdbool.h>
#define MAX_NODE (100)

typedef enum { DIRECTED = 0, UNDIRECTED = 1 } GraphType;

typedef struct {
	GraphType mode;
	bool nodeList[MAX_NODE];
	bool adjMatrix[MAX_NODE][MAX_NODE]; //int //bool
	int nodeSize;
}Graph;

void graphvizPrint(Graph *g);
void graphvizDriver(Graph *g);

void create(Graph* g, GraphType mode);
void destory(Graph* g);
void insertNode(Graph* g, int node);
void deleteNode(Graph* g, int node);
void insertEdge(Graph* g, int from, int to); //,int weight
void deleteEdge(Graph* g, int from, int to);
void print(const Graph* g);

int getNodeSize(Graph* g);
int getEdgeSize(Graph* g);


void recursiveDFS(const Graph* g, bool visited[], int start);
void BFS(const Graph* g, bool visited[], int start);

void connectedComponentDriver(const Graph* g, int component[]);
void connectedComponent(const Graph* g, int component[], int start, int componentNo);
void connectedComponentPrint(const Graph* g, int component[]);

Graph* spanningTreeDriver(const Graph *g);

void spanningTreeDFS(const Graph* g, int start, bool visited[], bool adjMatrix[][MAX_NODE]);