#pragma once
#include "graph.h"
#define MAX_NODE (100)

typedef struct Edge {
	int src, dest, weight;
}Edge;

typedef struct EdgeList {
	Edge data[MAX_NODE];
	int size;
}EdgeList;
#define ROOT(x) (parent[x]==-1)
void setInit(int parent[]);
int setFind(int parent[], int i);
void setUnion(int parent[], int x, int y);
int cmpfunc(const void* a, const void* b);
void sortEdgeList(Graph* g, EdgeList* elist);
Graph* kruskalMST(Graph* g);