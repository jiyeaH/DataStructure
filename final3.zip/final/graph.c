#include <stdio.h>
#include "graph.h"
#include "circularqueue.h"

/******************************************************************************
' GraphViz ��� �Լ�
'/******************************************************************************/
//*
void graphvizPrint(Graph *g) {
	char* mode;

	if (g->mode == DIRECTED) mode = "->";
	else mode = "--";

	for (int r = 0; r < g->nodeSize; r++) {
		if (g->nodeList[r]) printf("\t\"%d\";\n", r);
	}
	for (int r = 0; r < MAX_NODE; r++) {
		for (int c = 0; c < MAX_NODE; c++) {
			if (g->adjMatrix[r][c]) printf("\t\"%d\" %s \"%d\";\n", r, mode, c);
		}
	}
}

void graphvizDriver(Graph *g) {
	if (g->mode == DIRECTED) printf("digraph G {\n");
	else printf("graph G {\n");

	graphvizPrint(g);
	printf("}\n");
}//*/
void graphvizPrint2(Graph *g) {
	char* mode;

	if (g->mode == DIRECTED) mode = "->";
	else mode = "--";

	for (int r = 0; r < g->nodeSize; r++) {
		printf("\t\"%d\";\n", r);
	}

	if (g->mode == DIRECTED) {
		for (int r = 0; r < MAX_NODE; r++) {
			for (int c = 0; c < MAX_NODE; c++) {
				//����Ʈ�� ����ϱ� ���� ���� ����
				if (g->adjMatrix[r][c]) printf("\t\"%d\" %s \"%d\"[label=\"%d\"];\n", r, mode, c, g->adjMatrix[r][c]);
			}
		}
	}
	else if (g->mode == UNDIRECTED) {
		for (int r = 0; r < MAX_NODE; r++) {
			for (int c = 0; c < r; c++) {
				// ����Ʈ�� ����ϱ� ���� ���� ����
				if (g->adjMatrix[r][c]) printf("\t\"%d\" %s \"%d\"[label=\"%d\"];\n", r, mode, c, g->adjMatrix[r][c]);
			}
		}
	}
}


void graphvizDriver2(Graph *g) {
	if (g->mode == DIRECTED) printf("digraph G {\n");
	else printf("graph G {\n");

	graphvizPrint2(g);
	printf("}\n");
}


void create(Graph* g, GraphType mode) {
	int r, c;
	g->nodeSize = 0;
	g->mode = mode;
	for (r = 0; r < MAX_NODE; r++) {
		g->nodeList[r] = false;
		for (c = 0; c < MAX_NODE; c++) g->adjMatrix[r][c] = false;
	}
}
void destory(Graph* g) {
	create(g, g->mode);
}
void insertNode(Graph* g, int node) {
	if (node >= MAX_NODE) {
		printf("Error : node no out of range.\n");
		return;
	}
	g->nodeList[node] = true;
	(g->nodeSize)++;
}
void deleteNode(Graph* g, int node) {
	if (node >= MAX_NODE) {
		printf("Error : node no out of range.\n");
		return;
	}
	for (int i = 0; i < g->nodeSize; i++) {
		deleteEdge(g, i, node);
		deleteEdge(g, node, i);
	}
	g->nodeList[node] = false;
	if (node == (g->nodeSize) - 1) (g->nodeSize)--;
}
void insertEdge(Graph* g, int from, int to) { //int weight
	if (from < 0 || from >= g->nodeSize || to < 0 || to >= g->nodeSize) {
		printf("Error : node no out of range.\n");
		return;
	}
	g->adjMatrix[from][to] = true; //weight //true
	if (g->mode == UNDIRECTED) g->adjMatrix[to][from] = true; //weight //true
}
void deleteEdge(Graph* g, int from, int to) {
	if (from < 0 || from >= g->nodeSize || to < 0 || to >= g->nodeSize) {
		printf("Error : node no out of range.\n");
		return;
	}
	g->adjMatrix[from][to] = false;
	if (g->mode == UNDIRECTED) g->adjMatrix[to][from] = false;
}
void print(const Graph* g) {
	printf("Graph Print\n");
	for (int r = 0; r < g->nodeSize; r++) {
		for (int c = 0; c < g->nodeSize; c++) printf("%3d ", g->adjMatrix[r][c]);
		printf("\n");
	}
}
int getNodeSize(Graph* g) {
	int n;
	int count = 0;
	for (n = 0; n < g->nodeSize; n++) {
		if (g->nodeList[n]) count++;
	}
	return count;
}
int getEdgeSize(Graph* g) {
	int r, c;
	int count = 0;
	for (r = 0; r < g->nodeSize; r++) {
		for (c = 0; c < g->nodeSize; c++) {
			if (g->adjMatrix[r][c]) count++;
		}
	}
	return count;
}

void recursiveDFS(const Graph* g, bool visited[], int start) {
	visited[start] = true;
	printf("%d ", start);
	for (int v = 0; v < g->nodeSize; v++) {
		if (g->adjMatrix[start][v] && !visited[v]) recursiveDFS(g, visited, v);
	}
}
void BFS(const Graph* g, bool visited[], int start) {
	Queue q;
	init(&q);
	enQueue(&q, start);
	visited[start] = true;
	printf("%d ", start);
	while (!isEmpty(&q)) {
		int from = deQueue(&q);
		for (int to = 0; to < g->nodeSize; to++) {
			if (g->adjMatrix[from][to] && !visited[to]) {
				enQueue(&q, to);
				visited[to] = true;
				printf("%d ", to);
			}
		}
	}
	printf("\n");

}

void connectedComponentDriver(const Graph* g, int component[]) {
	int componentNo = 0;
	for (int i = 0; i < g->nodeSize; i++) {
		if (component[i] == 0) {
			componentNo++;
			connectedComponent(g, component, i, componentNo);
		}
	}
}
void connectedComponent(const Graph* g, int component[], int start, int componentNo) {
	component[start] = componentNo;
	for (int v = 0; v < g->nodeSize; v++) {
		if (g->adjMatrix[start][v] && !component[v])connectedComponent(g, component, v, componentNo);
	}
}
void connectedComponentPrint(const Graph* g, int component[]) {
	printf("\nConnected Component Print\n");
	for (int i = 0; i < g->nodeSize; i++) printf("%3d ", component[i]);
	printf("\n");
}

Graph* spanningTreeDriver(const Graph *g) {
	bool visited[MAX_NODE];
	for (int v = 0; v < MAX_NODE; v++) {
		visited[v] = false;
	}
	Graph* st = (Graph*)malloc(sizeof(Graph));
	create(st, UNDIRECTED);
	spanningTreeDFS(g, 2, visited, st->adjMatrix);
	return st;
}
void spanningTreeDFS(const Graph* g, int start, bool visited[], bool adjMatrix[][MAX_NODE]) {
	visited[start] = true;

	for (int v = 0; v < g->nodeSize; v++) {
		if (g->adjMatrix[start][v] && !visited[v]) {
			adjMatrix[start][v] = true;
			spanningTreeDFS(g, v, visited, adjMatrix);
		}
	}
}
